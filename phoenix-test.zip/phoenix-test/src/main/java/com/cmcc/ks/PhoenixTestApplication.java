package com.cmcc.ks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoenixTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhoenixTestApplication.class, args);
    }

}
