package com.yks.phoenix;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class PhoenixApplicationTests {

	@Autowired
	@Qualifier("phoenixJdbcTemplate")
	private JdbcTemplate phoenixJdbcTemplate;

	@Test
	public void contextLoads() {
//        List<Map<String, Object>> list  = phoenixJdbcTemplate.queryForList("select * from STOCK_SYMBOL");
		phoenixJdbcTemplate.execute("create table IF NOT EXISTS PHOENIX_TEST2 (ID INTEGER not null primary key, Name varchar(20),Age INTEGER)");
//        List<Map<String, Object>> list  = phoenixJdbcTemplate.queryForList("select * from STOCK_SYMBOL");
//        System.out.println(list);
	}

}
