# phoenix-hbase
phoenix 操作hbase和springboot的整合
开发环境：phoenix4.12,ubuntu16.10,idea,hortonworks hdp2.4.3 hbase1.1.2
说明：暂未找到对应的hbase-phoenix客户端maven依赖包，需要手动添加phoenix-4.12.0-HBase-1.1-client.jar驱动包(下载地址https://archive.apache.org/dist/phoenix/)

其中mytry是phoenix的scheme(类似mysql数据库概念)，company数据表结构和类型
ID:VARCHAR
NAME:VARCHAR
ADDRESS:VARCHAR


