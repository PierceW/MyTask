package io.github.ufukhalis.phoenix.mapper;

public enum  TableStrategy {

    CREATE,
    DROP_CREATE,
    NONE;
}
