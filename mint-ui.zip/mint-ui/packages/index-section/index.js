export { default } from './src/index-section.vue';
