export { default } from './src/navbar.vue';
